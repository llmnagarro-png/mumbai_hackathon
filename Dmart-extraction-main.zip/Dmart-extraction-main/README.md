# Dmart-extraction
